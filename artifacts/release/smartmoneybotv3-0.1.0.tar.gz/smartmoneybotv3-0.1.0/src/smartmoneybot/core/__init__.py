"""Deterministic market-structure core."""
